import microcontroller
import socketpool
import wifi
import time
import board
import neopixel
import mdns
import alarm
from adafruit_lc709203f import LC709203F

btmg = LC709203F(board.I2C())

pixel = neopixel.NeoPixel(board.NEOPIXEL, 1)
pixel.brightness = 1

mdnserv = mdns.Server(wifi.radio)
mdnserv.hostname = "myswimmingpool"
mdnserv.advertise_service(service_type="_http", protocol="_tcp", port=80)
wifi.radio.start_ap("thirdpartymexicangrandma", "tacobellwireless", authmode=[wifi.AuthMode.WPA, wifi.AuthMode.WPA2, wifi.AuthMode.PSK], max_connections=5)

from adafruit_httpserver import HTTPServer, HTTPResponse

pool = socketpool.SocketPool(wifi.radio)
server = HTTPServer(pool)

@server.route("/")
def base(request):
    body = """
    <p>You can turn on the server's RGB light <a href=http://192.168.4.1/neo>here</a>.</p>
    <p>You can play games <a href=http://192.168.4.1/games>here</a>.</p>
    """
    return HTTPResponse(content_type="text/html", body=body)

@server.route("/sysinfo")
def base(request):
    body = """
    <p>CPU Temperature: {temp:.1f}</p>
    <p>Battery Percent: {btpc:.2f}%</p>
    <p><a href=http://192.168.4.1/ds>Put server into sleep mode for 10 minutes.</a></p>
    <p><a href=http://192.168.4.1/rs>Reset the server.</a></p>
    <p>You can return <a href=http://192.168.4.1/>here</a>.</p>
    """.format(temp=microcontroller.cpu.temperature, btpc=btmg.cell_percent)
    return HTTPResponse(content_type="text/html", body=body)

@server.route("/neo")
def base(request):
    body = """
    <p>Done! You can return <a href=http://192.168.4.1/>here</a>.</p>
    """
    pixel.fill((0, 0, 255))
    time.sleep(0.5)
    pixel.fill((255, 255, 0))
    time.sleep(0.5)
    pixel.fill((0, 0, 0))
    return HTTPResponse(content_type="text/html", body=body)

@server.route("/ds")
def base(request):
    tmam = alarm.time.TimeAlarm(monotonic_time=time.monotonic() + (60 * 10))
    alarm.exit_and_deep_sleep_until_alarms(tmam)

@server.route("/rs")
def base(request):
    microcontroller.reset()

@server.route("/tetris")
def base(request):
    return HTTPResponse(filename="/tetris.html")

@server.route("/games")
def base(request):
    body = """
    <p><a href=http://192.168.4.1/tetris>Tetris</a>.</p>
    <p>You can return <a href=http://192.168.4.1/>here</a>.</p>
    """
    return HTTPResponse(content_type="text/html", body=body)

IP_ADDRESS = wifi.radio.ipv4_address_ap

# Never returns
server.serve_forever(str(IP_ADDRESS))
